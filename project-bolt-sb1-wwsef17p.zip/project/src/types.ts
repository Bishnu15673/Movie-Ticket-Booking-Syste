export interface Movie {
  id: string;
  title: string;
  imageUrl: string;
  description: string;
  duration: string;
  rating: string;
  showTimes: string[];
}

export interface Seat {
  id: string;
  row: string;
  number: number;
  isBooked: boolean;
  isSelected: boolean;
}

export interface Booking {
  movieId: string;
  showTime: string;
  seats: string[];
  totalPrice: number;
}

export interface Cinema {
  id: string;
  name: string;
  location: string;
  imageUrl: string;
}