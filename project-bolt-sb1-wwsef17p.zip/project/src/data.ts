import { Movie, Cinema } from './types';

export const movies: Movie[] = [
  {
    id: '1',
    title: 'Jaat',
    imageUrl: 'https://imgs.search.brave.com/Y4MN71MDAfq33xq7kcxLKmq_HUct_K_EMc9mWAbL41U/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9hc3Nl/dHNjZG4xLnBheXRt/LmNvbS9pbWFnZXMv/Y2luZW1hL0dhbGxl/cnklMjBpbWFnZV8w/MDE5X0phYXQ4LWMy/OGJmY2QwLTEwNjkt/MTFmMC05YmFkLTY1/MzFmYTA4ZWU4NC5q/cGc_Zm9ybWF0PXdl/YnA',
    description: 'Jaat is a massive action drama directed by Gopichand Malineni. The film stars Sunny Deol in the crucial role alongside Randeep Hooda, Vineet Kumar, Regina Cassandra, and Saiyami Kher.',
    duration: '2h 28min',
    rating: '9/10',
    showTimes: ['10:00 AM', '1:30 PM', '4:45 PM', '8:00 PM'],
  },
  {
    id: '2',
    title: 'Kesari Chapter 2',
    imageUrl: 'https://imgs.search.brave.com/Doo9lVJ8TimT0NHEJJ41Bro4j3TBVtm9XyaV7OP2lX8/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5hc3NldHR5cGUu/Y29tL291dGxvb2tp/bmRpYS8yMDI1LTAz/LTIyL2lwZ2hhdjF6/L2tlc2FyaS0yLmpw/ZWc_YXV0bz1mb3Jt/YXQsY29tcHJlc3Mm/Zml0PW1heCZmb3Jt/YXQ9d2VicCZ3PTc2/OCZkcHI9MS4w',
    description: 'Inspired by the annals of history, this is the riveting tale of Sankaran Nair, a fearless and charismatic barrister who waged an epic legal battle against the mighty British Empire, exposing to the world the brutal truth behind the Jallianwala Bagh Massacre.',
    duration: '2h 32min',
    Like: '60%',
    showTimes: ['11:00 AM', '2:30 PM', '5:45 PM', '9:00 PM'],
  },
  {
    id: '3',
    title: 'Akaal',
    imageUrl: 'https://imgs.search.brave.com/dpYxJyVDD3QKgBvME-roG56ZD2F77wMQ7QHUqxfAedk/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9pbWcu/bm93cnVubmluZy5j/b20vY29udGVudC9t/b3ZpZS8yMDI1L2Fr/YWFsLTMwNzM2L2Jn/X2FrYWFsLmpwZw',
    description: 'Set in 1840s Punjab, this gripping tale unfolds along the banks of a river, where the lives of two villages become intertwined.',
    duration: '2h 49min',
    rating: '8/10',
    showTimes: ['10:30 AM', '2:00 PM', '5:30 PM', '8:45 PM'],
  },
];

export const cinemas: Cinema[] = [
  {
    id: '1',
    name: 'Rajhans Cinemas',
    location: 'Bus Terminal, Una, Himachal Pradesh',
    imageUrl: 'https://imgs.search.brave.com/4kCrXgaa2uZd5AQTdMuIHqP89pKq7ZtePflkpRfYHXg/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9zdGF0/aWMud2lraWEubm9j/b29raWUubmV0L2xv/Z29wZWRpYS9pbWFn/ZXMvNS81Yy9SYWpo/YW5zX0NpbmVtYXMu/anBlZy9yZXZpc2lv/bi9sYXRlc3Qvc2Nh/bGUtdG8td2lkdGgt/ZG93bi8yNjA_Y2I9/MjAyMDA0MzAwODM1/NTk.jpeg'
  },
  {
    id: '2',
    name: 'PVR Cinemas',
    location: 'VR Mall, Kharar, Punjab',
    imageUrl: 'https://imgs.search.brave.com/4biBlg0wWTMpRoY41Vb1_SNThyr4SKU3Op0hSMIampg/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9jb21w/YW5pZXNsb2dvLmNv/bS9pbWcvb3JpZy9Q/VlIuTlNfQklHLTEw/MDdkN2M2LnBuZz90/PTE3MjAyNDQ0OTM'
  },
  {
    id: '3',
    name: 'Cinepolis',
    location: 'Bestech Square Mall, Mohali, Punjab',
    imageUrl: 'https://imgs.search.brave.com/nwoFGPPfHn00AvjqRnZ7QUWacnBgQOVltpPzCDUG7CQ/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9sb2dv/ZG93bmxvYWQub3Jn/L3dwLWNvbnRlbnQv/dXBsb2Fkcy8yMDE3/LzExL2NpbmVwb2xp/cy1sb2dvLTEucG5n'
  }
];