import React from 'react';
import { Clock, Star } from 'lucide-react';
import { Movie } from '../types';

interface MovieCardProps {
  movie: Movie;
  onSelect: (movie: Movie) => void;
}

export const MovieCard: React.FC<MovieCardProps> = ({ movie, onSelect }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform hover:scale-105 flex-shrink-0 w-80">
      <img
        src={movie.imageUrl}
        alt={movie.title}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-xl font-semibold mb-2">{movie.title}</h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{movie.description}</p>
        <div className="flex items-center gap-4 text-sm text-gray-500">
          <div className="flex items-center gap-1">
            <Clock size={16} />
            <span>{movie.duration}</span>
          </div>
          <div className="flex items-center gap-1">
            <Star size={16} />
            <span>{movie.rating}</span>
          </div>
        </div>
        <button
          onClick={() => onSelect(movie)}
          className="mt-4 w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition-colors"
        >
          Book Tickets
        </button>
      </div>
    </div>
  );
};