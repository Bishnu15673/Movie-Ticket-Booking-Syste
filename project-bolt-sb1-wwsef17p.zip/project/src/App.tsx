import React, { useState } from 'react';
import { Movie, Seat, Cinema } from './types';
import { movies, cinemas } from './data';
import { MovieCard } from './components/MovieCard';
import { SeatSelection } from './components/SeatSelection';
import { Calendar } from 'lucide-react';
import { Header } from './components/Header';
import { AuthProvider } from './context/AuthContext';
import { CinemaSelector } from './components/CinemaSelector';

function App() {
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [selectedCinema, setSelectedCinema] = useState<Cinema | null>(null);
  const [selectedShowTime, setSelectedShowTime] = useState<string>('');
  const [seats, setSeats] = useState<Seat[]>(
    Array.from({ length: 80 }, (_, i) => ({
      id: `seat-${i}`,
      row: String.fromCharCode(65 + Math.floor(i / 10)),
      number: (i % 10) + 1,
      isBooked: Math.random() < 0.3,
      isSelected: false,
    }))
  );

  const handleSeatSelect = (seatId: string) => {
    setSeats(seats.map(seat =>
      seat.id === seatId ? { ...seat, isSelected: !seat.isSelected } : seat
    ));
  };

  const selectedSeats = seats.filter(seat => seat.isSelected);
  const totalPrice = selectedSeats.length * 150;

  const handleBooking = () => {
    if (!selectedMovie || !selectedShowTime || selectedSeats.length === 0 || !selectedCinema) return;

    alert(`Booking confirmed!
Cinema: ${selectedCinema.name}
Movie: ${selectedMovie.title}
Time: ${selectedShowTime}
Seats: ${selectedSeats.map(seat => `${seat.row}${seat.number}`).join(', ')}
Total: ₹${totalPrice}`);

    // Reset selection
    setSelectedMovie(null);
    setSelectedCinema(null);
    setSelectedShowTime('');
    setSeats(seats.map(seat => ({
      ...seat,
      isSelected: false,
      isBooked: seat.isSelected ? true : seat.isBooked,
    })));
  };

  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-100">
        <Header />
        <main className="max-w-7xl mx-auto px-4 py-8">
          {!selectedCinema ? (
            <>
              <h2 className="text-2xl font-bold mb-6">Select a Cinema</h2>
              <CinemaSelector
                cinemas={cinemas}
                selectedCinema={selectedCinema}
                onSelect={setSelectedCinema}
              />
            </>
          ) : !selectedMovie ? (
            <>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Movies at {selectedCinema.name}</h2>
                <button
                  onClick={() => setSelectedCinema(null)}
                  className="text-blue-600 hover:text-blue-700"
                >
                  Change Cinema
                </button>
              </div>
              <div className="overflow-x-auto pb-4">
                <div className="flex gap-6 min-w-max">
                  {movies.map(movie => (
                    <MovieCard
                      key={movie.id}
                      movie={movie}
                      onSelect={setSelectedMovie}
                    />
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="space-y-8">
              <button
                onClick={() => {
                  setSelectedMovie(null);
                  setSelectedShowTime('');
                }}
                className="text-blue-600 hover:text-blue-700"
              >
                ← Back to movies
              </button>

              <div className="bg-white rounded-lg shadow-lg p-6">
                <div className="flex gap-6">
                  <img
                    src={selectedMovie.imageUrl}
                    alt={selectedMovie.title}
                    className="w-48 h-64 object-cover rounded"
                  />
                  <div>
                    <h2 className="text-2xl font-bold mb-2">{selectedMovie.title}</h2>
                    <p className="text-gray-600 mb-4">{selectedMovie.description}</p>
                    <div className="space-y-4">
                      <h3 className="font-semibold">Select Show Time</h3>
                      <div className="flex gap-2">
                        {selectedMovie.showTimes.map(time => (
                          <button
                            key={time}
                            onClick={() => setSelectedShowTime(time)}
                            className={`flex items-center gap-2 px-4 py-2 rounded ${
                              selectedShowTime === time
                                ? 'bg-blue-600 text-white'
                                : 'bg-gray-100 hover:bg-gray-200'
                            }`}
                          >
                            <Calendar size={16} />
                            {time}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {selectedShowTime && (
                <>
                  <div className="space-y-4">
                    <h3 className="text-xl font-semibold">Select Seats</h3>
                    <SeatSelection
                      seats={seats}
                      onSeatSelect={handleSeatSelect}
                    />
                  </div>

                  {selectedSeats.length > 0 && (
                    <div className="bg-white rounded-lg shadow-lg p-6">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-lg font-semibold">
                            Selected Seats: {selectedSeats.map(seat => `${seat.row}${seat.number}`).join(', ')}
                          </p>
                          <p className="text-gray-600">Total: ₹{totalPrice}</p>
                        </div>
                        <button
                          onClick={handleBooking}
                          className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 transition-colors"
                        >
                          Confirm Booking
                        </button>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </main>
      </div>
    </AuthProvider>
  );
}

export default App;