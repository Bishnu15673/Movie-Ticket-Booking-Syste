import React from 'react';
import { Cinema } from '../types';
import { MapPin } from 'lucide-react';

interface CinemaSelectorProps {
  cinemas: Cinema[];
  selectedCinema: Cinema | null;
  onSelect: (cinema: Cinema) => void;
}

export const CinemaSelector: React.FC<CinemaSelectorProps> = ({
  cinemas,
  selectedCinema,
  onSelect,
}) => {
  return (
    <div className="overflow-x-auto pb-4">
      <div className="flex gap-6 min-w-max">
        {cinemas.map((cinema) => (
          <div
            key={cinema.id}
            onClick={() => onSelect(cinema)}
            className={`cursor-pointer rounded-lg overflow-hidden shadow-lg transition-all flex-shrink-0 w-80 ${
              selectedCinema?.id === cinema.id
                ? 'ring-2 ring-blue-500 scale-105'
                : 'hover:scale-105'
            }`}
          >
            <img
              src={cinema.imageUrl}
              alt={cinema.name}
              className="w-full h-48 object-cover"
            />
            <div className="p-4 bg-white">
              <h3 className="text-xl font-semibold mb-2">{cinema.name}</h3>
              <div className="flex items-center text-gray-600">
                <MapPin size={16} className="mr-2" />
                <span>{cinema.location}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};