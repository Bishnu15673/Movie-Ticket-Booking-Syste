import React from 'react';
import { Seat } from '../types';

interface SeatSelectionProps {
  seats: Seat[];
  onSeatSelect: (seatId: string) => void;
}

export const SeatSelection: React.FC<SeatSelectionProps> = ({ seats, onSeatSelect }) => {
  const rows = Array.from(new Set(seats.map(seat => seat.row))).sort();

  return (
    <div className="p-6 bg-white rounded-lg shadow-lg">
      <div className="mb-8">
        <div className="flex gap-4 justify-center mb-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-gray-200 rounded"></div>
            <span>Available</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-blue-500 rounded"></div>
            <span>Selected</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-gray-500 rounded"></div>
            <span>Booked</span>
          </div>
        </div>
        <div className="w-1/2 h-2 bg-gray-300 mx-auto mb-8"></div>
      </div>
      <div className="grid gap-4">
        {rows.map(row => (
          <div key={row} className="flex justify-center gap-2">
            <div className="w-6 flex items-center">{row}</div>
            {seats
              .filter(seat => seat.row === row)
              .sort((a, b) => a.number - b.number)
              .map(seat => (
                <button
                  key={seat.id}
                  disabled={seat.isBooked}
                  onClick={() => onSeatSelect(seat.id)}
                  className={`w-6 h-6 rounded transition-colors ${
                    seat.isBooked
                      ? 'bg-gray-500 cursor-not-allowed'
                      : seat.isSelected
                      ? 'bg-blue-500 hover:bg-blue-600'
                      : 'bg-gray-200 hover:bg-gray-300'
                  }`}
                />
              ))}
          </div>
        ))}
      </div>
    </div>
  );
};